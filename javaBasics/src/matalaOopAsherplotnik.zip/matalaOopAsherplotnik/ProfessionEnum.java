package matalaOopAsherplotnik;

public enum ProfessionEnum {
	MATH, CHEMISTRY, GEOGRAPHY , LITERATURE, PHYSICS, SPORTS
}
